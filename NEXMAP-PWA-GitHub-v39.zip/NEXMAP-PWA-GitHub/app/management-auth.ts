const COOKIE_NAME = "nexmap_management";

async function managementToken() {
  const { env } = await import("cloudflare:workers");
  const password = String((env as unknown as Record<string, unknown>).MANAGEMENT_PASSWORD || "");
  if (!password) return "";
  const bytes = new TextEncoder().encode(`nexmap:${password}`);
  const digest = await crypto.subtle.digest("SHA-256", bytes);
  return Array.from(new Uint8Array(digest), byte => byte.toString(16).padStart(2, "0")).join("");
}

export async function isManagementAuthorized(request: Request) {
  const expected = await managementToken();
  if (!expected) return false;
  const cookies = request.headers.get("cookie") || "";
  const actual = cookies.split(";").map(value => value.trim()).find(value => value.startsWith(`${COOKIE_NAME}=`))?.slice(COOKIE_NAME.length + 1);
  return actual === expected;
}

export async function verifyManagementPassword(password: string) {
  const { env } = await import("cloudflare:workers");
  return password.length > 0 && password === String((env as unknown as Record<string, unknown>).MANAGEMENT_PASSWORD || "");
}

export async function managementCookie() {
  return `${COOKIE_NAME}=${await managementToken()}; Path=/; HttpOnly; Secure; SameSite=Strict; Max-Age=28800`;
}

export function clearManagementCookie() {
  return `${COOKIE_NAME}=; Path=/; HttpOnly; Secure; SameSite=Strict; Max-Age=0`;
}
