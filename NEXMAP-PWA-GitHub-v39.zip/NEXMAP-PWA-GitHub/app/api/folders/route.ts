import { asc, eq } from "drizzle-orm";
import { getDb } from "../../../db";
import { ctos, projectFolders } from "../../../db/schema";
import { isManagementAuthorized } from "../../management-auth";

export async function GET() {
  try {
    const db = await getDb();
    return Response.json({ folders: await db.select().from(projectFolders).orderBy(asc(projectFolders.name)) });
  } catch {
    return Response.json({ folders: [] });
  }
}

export async function POST(request: Request) {
  if (!await isManagementAuthorized(request)) return Response.json({ error: "Acesso de gestão necessário" }, { status: 401 });
  try {
    const { name } = await request.json() as { name?: string };
    const folderName = String(name || "").trim();
    if (!folderName) return Response.json({ error: "Nome da pasta obrigatório" }, { status: 400 });
    const db = await getDb();
    await db.insert(projectFolders).values({ name: folderName }).onConflictDoNothing();
    return Response.json({ folder: { name: folderName } }, { status: 201 });
  } catch {
    return Response.json({ error: "Não foi possível criar a pasta" }, { status: 500 });
  }
}

export async function PATCH(request: Request) {
  if (!await isManagementAuthorized(request)) return Response.json({ error: "Acesso de gestão necessário" }, { status: 401 });
  try {
    const { currentName, newName } = await request.json() as { currentName?: string; newName?: string };
    const source = String(currentName || "").trim();
    const destination = String(newName || "").trim();
    if (!source || !destination) return Response.json({ error: "Nomes da pasta são obrigatórios" }, { status: 400 });
    if (source === destination) return Response.json({ folder: { name: destination } });
    const db = await getDb();
    const existing = await db.select().from(projectFolders).where(eq(projectFolders.name, destination));
    if (existing.length) return Response.json({ error: "Já existe uma pasta com esse nome" }, { status: 409 });
    await db.update(ctos).set({ folder: destination }).where(eq(ctos.folder, source));
    const renamed = await db.update(projectFolders).set({ name: destination }).where(eq(projectFolders.name, source)).returning();
    if (!renamed.length) await db.insert(projectFolders).values({ name: destination }).onConflictDoNothing();
    return Response.json({ folder: { name: destination }, previousName: source });
  } catch {
    return Response.json({ error: "Não foi possível renomear a pasta" }, { status: 500 });
  }
}

export async function DELETE(request: Request) {
  if (!await isManagementAuthorized(request)) return Response.json({ error: "Acesso de gestão necessário" }, { status: 401 });
  try {
    const { name } = await request.json() as { name?: string };
    const folderName = String(name || "").trim();
    if (!folderName) return Response.json({ error: "Pasta inválida" }, { status: 400 });
    const db = await getDb();
    await db.delete(ctos).where(eq(ctos.folder, folderName));
    await db.delete(projectFolders).where(eq(projectFolders.name, folderName));
    return Response.json({ deleted: true, folder: folderName });
  } catch {
    return Response.json({ error: "Não foi possível excluir a pasta" }, { status: 500 });
  }
}
