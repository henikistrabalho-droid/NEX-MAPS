import { clearManagementCookie, isManagementAuthorized, managementCookie, verifyManagementPassword } from "../../management-auth";

export async function GET(request: Request) {
  return Response.json({ authorized: await isManagementAuthorized(request) });
}

export async function POST(request: Request) {
  const { password } = await request.json() as { password?: string };
  if (!await verifyManagementPassword(String(password || ""))) {
    return Response.json({ error: "Senha incorreta" }, { status: 401 });
  }
  return Response.json({ authorized: true }, { headers: { "set-cookie": await managementCookie() } });
}

export async function DELETE() {
  return Response.json({ authorized: false }, { headers: { "set-cookie": clearManagementCookie() } });
}
