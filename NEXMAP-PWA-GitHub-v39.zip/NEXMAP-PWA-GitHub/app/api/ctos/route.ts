import { asc, eq } from "drizzle-orm";
import { getDb } from "../../../db";
import { ctos } from "../../../db/schema";
import { isManagementAuthorized } from "../../management-auth";

export async function GET() {
  try {
    const db = await getDb();
    return Response.json({ ctos: await db.select().from(ctos).orderBy(asc(ctos.name)) });
  } catch {
    return Response.json({ ctos: [] });
  }
}

export async function POST(request: Request) {
  if (!await isManagementAuthorized(request)) return Response.json({ error: "Acesso de gestão necessário" }, { status: 401 });
  try {
    const p = await request.json() as typeof ctos.$inferInsert;
    if (!p.name || !Number.isFinite(p.latitude) || !Number.isFinite(p.longitude)) {
      return Response.json({ error: "Dados inválidos" }, { status: 400 });
    }
    const db = await getDb();
    const [cto] = await db.insert(ctos).values(p).returning();
    return Response.json({ cto }, { status: 201 });
  } catch {
    return Response.json({ error: "Não foi possível salvar" }, { status: 500 });
  }
}

export async function PATCH(request: Request) {
  if (!await isManagementAuthorized(request)) return Response.json({ error: "Acesso de gestão necessário" }, { status: 401 });
  try {
    const p = await request.json() as Partial<typeof ctos.$inferInsert> & { id?: number };
    if (!p.id || !Number.isFinite(p.id)) {
      return Response.json({ error: "CTO inválida" }, { status: 400 });
    }
    const { id, ...changes } = p;
    const db = await getDb();
    const [cto] = await db.update(ctos).set(changes).where(eq(ctos.id, id)).returning();
    if (!cto) return Response.json({ error: "CTO não encontrada" }, { status: 404 });
    return Response.json({ cto });
  } catch {
    return Response.json({ error: "Não foi possível atualizar" }, { status: 500 });
  }
}

export async function DELETE(request: Request) {
  if (!await isManagementAuthorized(request)) return Response.json({ error: "Acesso de gestão necessário" }, { status: 401 });
  try {
    const { id, folder } = await request.json() as { id?: number; folder?: string };
    if (folder?.trim()) {
      const db = await getDb();
      const deleted = await db.delete(ctos).where(eq(ctos.folder, folder.trim())).returning();
      return Response.json({ deleted: true, count: deleted.length, folder: folder.trim() });
    }
    if (!id || !Number.isFinite(id)) return Response.json({ error: "CTO ou pasta inválida" }, { status: 400 });
    const db = await getDb();
    const [cto] = await db.delete(ctos).where(eq(ctos.id, id)).returning();
    if (!cto) return Response.json({ error: "CTO não encontrada" }, { status: 404 });
    return Response.json({ deleted: true, cto });
  } catch {
    return Response.json({ error: "Não foi possível excluir" }, { status: 500 });
  }
}
