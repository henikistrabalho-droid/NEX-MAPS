"use client";

import { ChangeEvent, FormEvent, useEffect, useMemo, useRef, useState } from "react";
import type { Layer, Map as LeafletMap, Marker as LeafletMarker, Polyline as LeafletPolyline } from "leaflet";
import JSZip from "jszip";

type Cto = {
  id: number; name: string; address: string; latitude: number; longitude: number;
  totalPorts: number; occupiedPorts: number; power: string; status: string; notes: string; color?: string; folder?: string;
};

type Cable = {
  id: number; name: string; type: string; color: string; points: [number, number][]; visible: boolean; sourceFolder?: string;
};

type InstallPromptEvent = Event & {
  prompt: () => Promise<void>;
  userChoice: Promise<{ outcome: "accepted" | "dismissed" }>;
};

const demo: Cto[] = [
  { id: -1, name: "CTO MC-018", address: "Estrada de Morro do Coco", latitude: -21.1869, longitude: -41.6228, totalPorts: 8, occupiedPorts: 3, power: "-17,2 dBm", status: "Ativa", notes: "Poste próximo ao mercado." },
  { id: -2, name: "CTO MC-024", address: "Rua Principal", latitude: -21.1912, longitude: -41.6154, totalPorts: 16, occupiedPorts: 12, power: "-19,4 dBm", status: "Ativa", notes: "Caixa instalada no poste 42." },
  { id: -3, name: "CTO MC-031", address: "Fazenda União", latitude: -21.1801, longitude: -41.6295, totalPorts: 8, occupiedPorts: 8, power: "-20,1 dBm", status: "Lotada", notes: "Sem portas livres." },
];

function routeColor(routeNumber: number, suffix = "") {
  // The golden-angle spacing avoids the repeated colors caused by a short palette.
  const suffixOffset = Array.from(suffix).reduce((total, character) => total + character.charCodeAt(0), 0);
  const hue = ((routeNumber * 137.508) + (suffixOffset * 29)) % 360;
  const saturation = 72;
  const lightness = 45;
  const chroma = (1 - Math.abs((2 * lightness / 100) - 1)) * saturation / 100;
  const segment = hue / 60;
  const secondary = chroma * (1 - Math.abs((segment % 2) - 1));
  const [red, green, blue] = segment < 1 ? [chroma, secondary, 0]
    : segment < 2 ? [secondary, chroma, 0]
      : segment < 3 ? [0, chroma, secondary]
        : segment < 4 ? [0, secondary, chroma]
          : segment < 5 ? [secondary, 0, chroma]
            : [chroma, 0, secondary];
  const match = lightness / 100 - chroma / 2;
  return `#${[red, green, blue].map(channel => Math.round((channel + match) * 255).toString(16).padStart(2, "0")).join("")}`;
}

function colorByRouteName(value: string, fallback: string) {
  const normalized = value.toUpperCase().replace(/\s+/g, " ");
  const explicitRoute = normalized.match(/\bR(?:AMAL)?\s*[-_.]?\s*0*(\d+)([A-Z]?)\b/);
  const ctoIdentification = normalized.match(/\bCTO?\s*[- ]*\s*0*(\d+)\s*[.\-]\s*0*(\d+)(?!\d)/);
  const routeNumber = explicitRoute ? Number(explicitRoute[1]) : ctoIdentification ? Number(ctoIdentification[2]) : 0;
  const routeSuffix = explicitRoute?.[2] || "";
  return routeNumber ? routeColor(routeNumber, routeSuffix) : fallback;
}

function folderOf(cto: Cto) {
  if (cto.folder) return cto.folder;
  const importedFile = cto.notes?.match(/Arquivo:\s*(.+)$/)?.[1]?.trim();
  return importedFile || "CTOs cadastradas";
}

function escapeMarkerText(value: string) {
  return value.replace(/[&<>"']/g, character => ({
    "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#039;",
  })[character] || character);
}

export default function MapApp() {
  const mapEl = useRef<HTMLDivElement>(null);
  const mapRef = useRef<LeafletMap | null>(null);
  const tileLayerRef = useRef<Layer | null>(null);
  const markerRefs = useRef<LeafletMarker[]>([]);
  const cableRefs = useRef<LeafletPolyline[]>([]);
  const importFileRef = useRef<HTMLInputElement>(null);
  const leafletRef = useRef<typeof import("leaflet") | null>(null);
  const [ctos, setCtos] = useState<Cto[]>(() => {
    if (typeof window === "undefined") return demo;
    try {
      const saved = JSON.parse(localStorage.getItem("nexmap-ctos-offline") || "[]");
      return Array.isArray(saved) && saved.length ? saved : demo;
    } catch { return demo; }
  });
  const [selected, setSelected] = useState<Cto | null>(null);
  const [activePanel, setActivePanel] = useState<"list" | "search" | "add" | "cables" | null>(null);
  const [mapReady, setMapReady] = useState(false);
  const [query, setQuery] = useState("");
  const [formOpen, setFormOpen] = useState(false);
  const [importOpen, setImportOpen] = useState(false);
  const [editOpen, setEditOpen] = useState(false);
  const [folderOpen, setFolderOpen] = useState(false);
  const [moveFolderName, setMoveFolderName] = useState<string | null>(null);
  const [moveDestination, setMoveDestination] = useState("");
  const [deleteFolderName, setDeleteFolderName] = useState<string | null>(null);
  const [deletingFolder, setDeletingFolder] = useState(false);
  const [editFolderName, setEditFolderName] = useState<string | null>(null);
  const [editFolderValue, setEditFolderValue] = useState("");
  const [relocatingId, setRelocatingId] = useState<number | null>(null);
  const [importSource, setImportSource] = useState<"Google Earth" | "GeoGrid">("Google Earth");
  const [importFolderChoice, setImportFolderChoice] = useState("__new__");
  const [newImportFolder, setNewImportFolder] = useState("");
  const [picked, setPicked] = useState({ lat: -21.21478, lng: -41.58928 });
  const [toast, setToast] = useState("");
  const [mapStyle, setMapStyle] = useState<"map" | "satellite">("satellite");
  const [splashVisible, setSplashVisible] = useState(true);
  const [installPrompt, setInstallPrompt] = useState<InstallPromptEvent | null>(null);
  const [installed, setInstalled] = useState(() => typeof window !== "undefined" && window.matchMedia("(display-mode: standalone)").matches);
  const [isIos] = useState(() => typeof navigator !== "undefined" && /iphone|ipad|ipod/i.test(navigator.userAgent));
  const [isAndroid] = useState(() => typeof navigator !== "undefined" && /android/i.test(navigator.userAgent));
  const [isOnline, setIsOnline] = useState(() => typeof navigator === "undefined" || navigator.onLine);
  const [activeFolder, setActiveFolder] = useState<string | null>("CTOs cadastradas");
  const [visibleFolders, setVisibleFolders] = useState<Set<string>>(new Set(["CTOs cadastradas"]));
  const [ctosExpanded, setCtosExpanded] = useState(true);
  const [technicianMode, setTechnicianMode] = useState(true);
  const [authOpen, setAuthOpen] = useState(false);
  const [authError, setAuthError] = useState("");
  const [nearestId, setNearestId] = useState<number | null>(null);
  const [cables, setCables] = useState<Cable[]>(() => {
    if (typeof window === "undefined") return [];
    try { return JSON.parse(localStorage.getItem("nexmap-cables") || "[]"); } catch { return []; }
  });
  const [drawingCable, setDrawingCable] = useState(false);
  const [cablePoints, setCablePoints] = useState<[number, number][]>([]);
  const [cablesExpanded, setCablesExpanded] = useState(true);
  const [manualFolders, setManualFolders] = useState<string[]>(() => {
    if (typeof window === "undefined") return [];
    try { return JSON.parse(localStorage.getItem("nexmap-folders") || "[]"); } catch { return []; }
  });

  useEffect(() => {
    fetch("/api/ctos").then(r => r.ok ? r.json() : null).then(data => {
      if (data?.ctos?.length) {
        setCtos(data.ctos);
        localStorage.setItem("nexmap-ctos-offline", JSON.stringify(data.ctos));
        const folderNames = Array.from(new Set<string>(data.ctos.map((cto: Cto) => folderOf(cto))));
        const initialFolder = folderNames.includes("CTOs cadastradas") ? "CTOs cadastradas" : folderNames[0];
        setVisibleFolders(initialFolder ? new Set([initialFolder]) : new Set());
        setActiveFolder(initialFolder || null);
      }
    }).catch(() => {});
    fetch("/api/folders").then(r => r.ok ? r.json() : null).then(data => {
      if (Array.isArray(data?.folders)) {
        setManualFolders(current => Array.from(new Set([...current, ...data.folders.map((folder: { name: string }) => folder.name)])));
      }
    }).catch(() => {});
  }, []);

  useEffect(() => {
    const online = () => { setIsOnline(true); setToast("Conexão restabelecida. Dados online disponíveis."); };
    const offline = () => { setIsOnline(false); setToast("Modo offline ativado. Exibindo os dados salvos neste aparelho."); };
    window.addEventListener("online", online);
    window.addEventListener("offline", offline);
    return () => { window.removeEventListener("online", online); window.removeEventListener("offline", offline); };
  }, []);

  useEffect(() => {
    const timer = window.setTimeout(() => setSplashVisible(false), 1500);
    return () => window.clearTimeout(timer);
  }, []);

  useEffect(() => {
    if ("serviceWorker" in navigator) {
      navigator.serviceWorker.register("/sw.js").catch(() => {});
    }
    const capturePrompt = (event: Event) => {
      event.preventDefault();
      setInstallPrompt(event as InstallPromptEvent);
    };
    const markInstalled = () => {
      setInstalled(true);
      setInstallPrompt(null);
    };
    window.addEventListener("beforeinstallprompt", capturePrompt);
    window.addEventListener("appinstalled", markInstalled);
    return () => {
      window.removeEventListener("beforeinstallprompt", capturePrompt);
      window.removeEventListener("appinstalled", markInstalled);
    };
  }, []);

  async function installApp() {
    if (installPrompt) {
      await installPrompt.prompt();
      const choice = await installPrompt.userChoice;
      if (choice.outcome === "accepted") setInstalled(true);
      setInstallPrompt(null);
      return;
    }
    if (isIos) {
      setToast("No iPhone: toque em Compartilhar e em “Adicionar à Tela de Início”. O iOS exige essa confirmação.");
      return;
    }
    setToast("Abra o menu do navegador e escolha “Instalar aplicativo” ou “Adicionar à tela inicial”.");
  }

  useEffect(() => {
    if (!mapEl.current || mapRef.current) return;
    let active = true;
    import("leaflet").then(L => {
      if (!active || !mapEl.current) return;
      leafletRef.current = L;
      const map = L.map(mapEl.current, { zoomControl: false }).setView([-21.19, -41.62], 14);
      tileLayerRef.current = L.tileLayer("https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png", {
        attribution: "© OpenStreetMap", maxZoom: 20,
      }).addTo(map);
      L.control.zoom({ position: "bottomright" }).addTo(map);
      map.on("click", e => {
        if (document.body.dataset.managementMode !== "true") return;
        if (document.body.dataset.drawingCable === "true") {
          setCablePoints(current => [...current, [e.latlng.lat, e.latlng.lng]]);
          return;
        }
        setPicked({ lat: e.latlng.lat, lng: e.latlng.lng });
        setFormOpen(true);
      });
      mapRef.current = map;
      setMapReady(true);
    });
    return () => { active = false; mapRef.current?.remove(); mapRef.current = null; tileLayerRef.current = null; setMapReady(false); };
  }, []);

  useEffect(() => {
    document.body.dataset.drawingCable = drawingCable ? "true" : "false";
    return () => { delete document.body.dataset.drawingCable; };
  }, [drawingCable]);

  useEffect(() => {
    document.body.dataset.managementMode = technicianMode ? "false" : "true";
    return () => { delete document.body.dataset.managementMode; };
  }, [technicianMode]);

  useEffect(() => {
    localStorage.setItem("nexmap-cables", JSON.stringify(cables));
  }, [cables]);

  useEffect(() => {
    if (ctos.length) localStorage.setItem("nexmap-ctos-offline", JSON.stringify(ctos));
  }, [ctos]);

  useEffect(() => {
    localStorage.setItem("nexmap-folders", JSON.stringify(manualFolders));
  }, [manualFolders]);

  useEffect(() => {
    const L = leafletRef.current, map = mapRef.current;
    if (!L || !map || !mapReady) return;
    tileLayerRef.current?.remove();
    if (mapStyle === "satellite") {
      const imagery = L.tileLayer("https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}", {
        attribution: "Imagens e referências © Esri", maxNativeZoom: 18, maxZoom: 20,
      });
      const roads = L.tileLayer("https://server.arcgisonline.com/ArcGIS/rest/services/Reference/World_Transportation/MapServer/tile/{z}/{y}/{x}", {
        maxNativeZoom: 18, maxZoom: 20,
      });
      const labels = L.tileLayer("https://server.arcgisonline.com/ArcGIS/rest/services/Reference/World_Boundaries_and_Places/MapServer/tile/{z}/{y}/{x}", {
        maxNativeZoom: 18, maxZoom: 20,
      });
      tileLayerRef.current = L.layerGroup([imagery, roads, labels]).addTo(map);
    } else {
      tileLayerRef.current = L.tileLayer("https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png", {
          attribution: "© OpenStreetMap", maxZoom: 20,
        }).addTo(map);
    }
  }, [mapStyle, mapReady]);

  useEffect(() => {
    const L = leafletRef.current, map = mapRef.current;
    if (!L || !map) return;
    markerRefs.current.forEach(m => m.remove());
    const visibleCtos = ctos.filter(cto => visibleFolders.has(folderOf(cto)));
    markerRefs.current = visibleCtos.map(cto => {
      const ctoName = escapeMarkerText(cto.name);
      const markerColor = colorByRouteName(cto.name, cto.color || (cto.occupiedPorts >= cto.totalPorts ? "#f97316" : "#18a875"));
      const icon = L.divIcon({
        className: "",
        html: `<div class="cto-map-symbol ${relocatingId === cto.id ? "relocating" : ""}" style="--marker-color:${markerColor}"><span><img src="/cto-marker.jpg" alt="" /></span><strong>${ctoName}</strong></div>`,
        iconSize: [96, 53],
        iconAnchor: [48, 28],
      });
      const marker = L.marker([cto.latitude, cto.longitude], {
        icon, title: cto.name, alt: cto.name, draggable: relocatingId === cto.id,
      }).addTo(map).on("click", () => drawingCable ? addCtoToCable(cto) : setSelected(cto));
      marker.on("dragend", async event => {
        const position = event.target.getLatLng();
        await updateCto(cto, { latitude: position.lat, longitude: position.lng });
        setRelocatingId(null);
        setToast("Nova posição da CTO salva.");
      });
      return marker;
    });
  }, [ctos, mapReady, relocatingId, visibleFolders, drawingCable]);

  useEffect(() => {
    const L = leafletRef.current, map = mapRef.current;
    if (!L || !map) return;
    cableRefs.current.forEach(line => line.remove());
    const savedLines = cables.filter(cable => cable.visible && visibleFolders.has(cable.sourceFolder || "CTOs cadastradas")).map(cable => L.polyline(cable.points, {
      color: colorByRouteName(cable.name, cable.color), weight: 5, opacity: .9,
    }).addTo(map).bindTooltip(`${cable.name} • ${cable.type}`, { className: "route-tooltip" }));
    if (cablePoints.length) savedLines.push(L.polyline(cablePoints, { color: "#f97316", weight: 5, dashArray: "8 7" }).addTo(map));
    cableRefs.current = savedLines;
  }, [cables, cablePoints, mapReady, visibleFolders]);

  const folders = useMemo(() => {
    const grouped = new Map<string, { ctos: number; cables: number }>();
    manualFolders.forEach(name => grouped.set(name, { ctos: 0, cables: 0 }));
    ctos.forEach(cto => {
      const name = folderOf(cto), current = grouped.get(name) || { ctos: 0, cables: 0 };
      grouped.set(name, { ...current, ctos: current.ctos + 1 });
    });
    cables.forEach(cable => {
      const cableFolder = cable.sourceFolder || "CTOs cadastradas";
      const current = grouped.get(cableFolder) || { ctos: 0, cables: 0 };
      grouped.set(cableFolder, { ...current, cables: current.cables + 1 });
    });
    return Array.from(grouped, ([name, counts]) => ({ name, count: counts.ctos + counts.cables, ...counts }));
  }, [ctos, cables, manualFolders]);

  const filtered = useMemo(() => ctos.filter(c => {
    const matchesFolder = activePanel === "search" || (activeFolder && folderOf(c) === activeFolder);
    return matchesFolder && `${c.name} ${c.address}`.toLowerCase().includes(query.toLowerCase());
  }), [ctos, query, activeFolder, activePanel]);

  const allFoldersVisible = folders.length > 0 && folders.every(folder => visibleFolders.has(folder.name));

  function distanceKm(lat1: number, lng1: number, lat2: number, lng2: number) {
    const rad = (value: number) => value * Math.PI / 180;
    const dLat = rad(lat2 - lat1), dLng = rad(lng2 - lng1);
    const a = Math.sin(dLat / 2) ** 2 + Math.cos(rad(lat1)) * Math.cos(rad(lat2)) * Math.sin(dLng / 2) ** 2;
    return 6371 * 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
  }

  function locateMe() {
    if (!navigator.geolocation) return setToast("Localização não disponível neste aparelho.");
    navigator.geolocation.getCurrentPosition(p => {
      const latitude = p.coords.latitude, longitude = p.coords.longitude;
      const visible = ctos.filter(cto => visibleFolders.has(folderOf(cto)));
      const nearest = visible.reduce<{ cto: Cto; distance: number } | null>((best, cto) => {
        const distance = distanceKm(latitude, longitude, cto.latitude, cto.longitude);
        return !best || distance < best.distance ? { cto, distance } : best;
      }, null);
      if (!nearest) return setToast("Nenhuma CTO visível para comparar.");
      setNearestId(nearest.cto.id);
      setSelected(nearest.cto);
      mapRef.current?.fitBounds([[latitude, longitude], [nearest.cto.latitude, nearest.cto.longitude]], { padding: [70, 70], maxZoom: 18 });
      setToast(`${nearest.cto.name} é a mais próxima: ${nearest.distance < 1 ? `${Math.round(nearest.distance * 1000)} m` : `${nearest.distance.toFixed(2)} km`}.`);
    }, () => setToast("Não foi possível acessar sua localização. Autorize o GPS do aparelho."), { enableHighAccuracy: true, timeout: 12000 });
  }

  function focus(cto: Cto) {
    setActiveFolder(folderOf(cto));
    setVisibleFolders(new Set([folderOf(cto)]));
    setSelected(cto);
    setActivePanel(null);
    mapRef.current?.flyTo([cto.latitude, cto.longitude], 18);
  }

  function togglePanel(panel: "list" | "search" | "add" | "cables") {
    setActivePanel(current => current === panel ? null : panel);
  }

  function beginCable() {
    setCablePoints([]); setDrawingCable(true); setActivePanel(null);
    setToast("Toque no mapa para marcar o caminho do cabo. Use “Concluir cabo” ao terminar.");
  }

  function addCtoToCable(cto: Cto) {
    if (!drawingCable) return;
    setCablePoints(current => [...current, [cto.latitude, cto.longitude]]);
  }

  function finishCable() {
    if (cablePoints.length < 2) return setToast("Marque pelo menos dois pontos para criar o cabo.");
    setDrawingCable(false); setActivePanel("cables");
  }

  function saveCable(e: FormEvent<HTMLFormElement>) {
    e.preventDefault();
    const fd = new FormData(e.currentTarget);
    setCables(current => [...current, { id: Date.now(), name: String(fd.get("name")), type: String(fd.get("type")), color: String(fd.get("color")), points: cablePoints, visible: true, sourceFolder: activeFolder || "CTOs cadastradas" }]);
    setCablePoints([]); setToast("Cabo adicionado ao mapa.");
  }

  function toggleCable(id: number) {
    setCables(current => current.map(cable => cable.id === id ? { ...cable, visible: !cable.visible } : cable));
  }

  function deleteCable(id: number) {
    if (technicianMode) return;
    const cable = cables.find(item => item.id === id);
    if (!cable || !window.confirm(`Excluir o cabo “${cable.name}” definitivamente?`)) return;
    setCables(current => current.filter(cable => cable.id !== id));
    setToast("Cabo removido do mapa.");
  }

  async function deleteFolder(folderName: string) {
    if (technicianMode || deletingFolder) return;
    setDeletingFolder(true);
    try {
      const response = await fetch("/api/folders", {
        method: "DELETE",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({ name: folderName }),
      });
      if (!response.ok) throw new Error();
    } catch {
      setDeletingFolder(false);
      setDeleteFolderName(null);
      return setToast("Não foi possível excluir a pasta. Entre novamente no Modo Gestão.");
    }
    setCtos(current => current.filter(cto => folderOf(cto) !== folderName));
    setCables(current => current.filter(cable => (cable.sourceFolder || "CTOs cadastradas") !== folderName));
    setManualFolders(current => current.filter(name => name !== folderName));
    setVisibleFolders(current => { const next = new Set(current); next.delete(folderName); return next; });
    if (activeFolder === folderName) setActiveFolder(null);
    setSelected(current => current && folderOf(current) === folderName ? null : current);
    setDeletingFolder(false);
    setDeleteFolderName(null);
    setToast(`Pasta “${folderName}” excluída com suas CTOs e cabos.`);
  }

  function openMoveFolder(folderName: string) {
    const firstDestination = folders.find(folder => folder.name !== folderName)?.name || "";
    setMoveFolderName(folderName);
    setMoveDestination(firstDestination);
  }

  function openEditFolder(folderName: string) {
    setEditFolderName(folderName);
    setEditFolderValue(folderName);
  }

  async function renameFolder(e: FormEvent<HTMLFormElement>) {
    e.preventDefault();
    const source = editFolderName;
    const destination = editFolderValue.trim();
    if (technicianMode || !source || !destination) return;
    if (folders.some(folder => folder.name !== source && folder.name.toLocaleLowerCase("pt-BR") === destination.toLocaleLowerCase("pt-BR"))) {
      return setToast("Já existe uma pasta com esse nome.");
    }
    const response = await fetch("/api/folders", {
      method: "PATCH", headers: { "content-type": "application/json" }, body: JSON.stringify({ currentName: source, newName: destination }),
    });
    if (!response.ok) return setToast("Não foi possível alterar o nome da pasta.");
    setCtos(current => current.map(cto => folderOf(cto) === source ? { ...cto, folder: destination } : cto));
    setCables(current => current.map(cable => (cable.sourceFolder || "CTOs cadastradas") === source ? { ...cable, sourceFolder: destination } : cable));
    setManualFolders(current => Array.from(new Set(current.map(name => name === source ? destination : name))));
    setVisibleFolders(current => current.has(source) ? new Set([destination]) : current);
    if (activeFolder === source) setActiveFolder(destination);
    setSelected(current => current && folderOf(current) === source ? { ...current, folder: destination } : current);
    setEditFolderName(null);
    setToast(`Pasta renomeada para “${destination}”.`);
  }

  async function moveFolderContents(e: FormEvent<HTMLFormElement>) {
    e.preventDefault();
    const source = moveFolderName;
    const destination = moveDestination.trim();
    if (technicianMode || !source || !destination || source === destination) return;
    const serverCtos = ctos.filter(cto => cto.id > 0 && folderOf(cto) === source);
    const results = await Promise.all(serverCtos.map(cto => fetch("/api/ctos", {
      method: "PATCH",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ id: cto.id, folder: destination }),
    })));
    if (results.some(response => !response.ok)) {
      setToast("Não foi possível mover todos os elementos. Entre novamente no Modo Gestão.");
      return;
    }
    await fetch("/api/folders", { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify({ name: destination }) });
    await fetch("/api/folders", { method: "DELETE", headers: { "content-type": "application/json" }, body: JSON.stringify({ name: source }) });
    setCtos(current => current.map(cto => folderOf(cto) === source ? { ...cto, folder: destination } : cto));
    setCables(current => current.map(cable => (cable.sourceFolder || "CTOs cadastradas") === source ? { ...cable, sourceFolder: destination } : cable));
    setManualFolders(current => Array.from(new Set([...current.filter(name => name !== source), destination])));
    setVisibleFolders(new Set([destination]));
    setActiveFolder(destination);
    setMoveFolderName(null);
    setToast(`Elementos movidos de “${source}” para “${destination}”.`);
  }

  async function createFolder(e: FormEvent<HTMLFormElement>) {
    e.preventDefault();
    const folderName = String(new FormData(e.currentTarget).get("folderName") || "").trim();
    if (!folderName) return;
    if (folders.some(folder => folder.name.toLocaleLowerCase("pt-BR") === folderName.toLocaleLowerCase("pt-BR"))) {
      setToast("Já existe uma pasta com esse nome.");
      return;
    }
    const response = await fetch("/api/folders", { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify({ name: folderName }) });
    if (!response.ok) return setToast("Não foi possível criar a pasta. Entre novamente no Modo Gestão.");
    setManualFolders(current => [...current, folderName]);
    setVisibleFolders(new Set([folderName]));
    setActiveFolder(folderName); setFolderOpen(false); setCtosExpanded(true);
    setToast(`Pasta “${folderName}” criada. Agora você pode importar arquivos para ela.`);
  }

  function toggleFolderVisibility(folderName: string) {
    setVisibleFolders(new Set([folderName]));
    setActiveFolder(folderName);
  }

  function toggleAllElements() {
    if (allFoldersVisible) {
      setVisibleFolders(new Set());
      setSelected(null);
    } else {
      const names = folders.map(folder => folder.name);
      setVisibleFolders(new Set(names));
    }
  }

  async function updateCto(cto: Cto, changes: Partial<Cto>) {
    const updated = { ...cto, ...changes };
    setCtos(current => current.map(item => item.id === cto.id ? updated : item));
    setSelected(current => current?.id === cto.id ? updated : current);
    if (cto.id <= 0) return updated;
    try {
      const response = await fetch("/api/ctos", {
        method: "PATCH",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({ id: cto.id, ...changes }),
      });
      if (!response.ok) throw new Error();
      const saved = (await response.json()).cto as Cto;
      setCtos(current => current.map(item => item.id === cto.id ? saved : item));
      setSelected(current => current?.id === cto.id ? saved : current);
      return saved;
    } catch {
      setToast("Alteração mantida nesta tela, mas não foi possível salvar no servidor.");
      return updated;
    }
  }

  async function editCto(e: FormEvent<HTMLFormElement>) {
    e.preventDefault();
    if (!selected) return;
    const fd = new FormData(e.currentTarget);
    await updateCto(selected, {
      name: String(fd.get("name")),
      address: String(fd.get("address")),
      color: String(fd.get("color")),
      latitude: Number(fd.get("latitude")),
      longitude: Number(fd.get("longitude")),
      totalPorts: Number(fd.get("totalPorts")),
      occupiedPorts: Number(fd.get("occupiedPorts")),
      power: String(fd.get("power")),
      status: String(fd.get("status")),
      notes: String(fd.get("notes")),
      folder: String(fd.get("folder")) || "CTOs cadastradas",
    });
    setEditOpen(false);
    setToast("CTO atualizada com sucesso.");
  }

  function startRelocating() {
    if (!selected) return;
    setRelocatingId(selected.id);
    setSelected(null);
    setToast("Arraste a caixa CTO até a nova posição no mapa.");
  }

  async function deleteCto(target: Cto | null = selected) {
    if (technicianMode || !target || !window.confirm(`Excluir ${target.name} definitivamente?`)) return;
    if (target.id > 0) {
      const response = await fetch("/api/ctos", { method: "DELETE", headers: { "content-type": "application/json" }, body: JSON.stringify({ id: target.id }) });
      if (!response.ok) return setToast("Não foi possível excluir esta CTO.");
    }
    setCtos(current => current.filter(item => item.id !== target.id));
    setSelected(current => current?.id === target.id ? null : current); setEditOpen(false);
    setToast(`${target.name} excluída do mapa.`);
  }

  function kmlDocument() {
    const placemarks = ctos.map(cto => `<Placemark><name>${escapeMarkerText(cto.name)}</name><description><![CDATA[${cto.address}\nPortas: ${cto.occupiedPorts}/${cto.totalPorts}\nPotência: ${cto.power}\n${cto.notes}]]></description><Point><coordinates>${cto.longitude},${cto.latitude},0</coordinates></Point></Placemark>`).join("");
    const cableLines = cables.map(cable => { const color = colorByRouteName(cable.name, cable.color); return `<Placemark><name>${escapeMarkerText(cable.name)}</name><description><![CDATA[Tipo: ${cable.type}]]></description><Style><LineStyle><color>ff${color.replace("#", "").match(/.{2}/g)?.reverse().join("") || "1673f9"}</color><width>5</width></LineStyle></Style><LineString><tessellate>1</tessellate><coordinates>${cable.points.map(([latitude, longitude]) => `${longitude},${latitude},0`).join(" ")}</coordinates></LineString></Placemark>`; }).join("");
    return `<?xml version="1.0" encoding="UTF-8"?><kml xmlns="http://www.opengis.net/kml/2.2"><Document><name>NEX'MAP - Rede FTTH</name>${placemarks}${cableLines}</Document></kml>`;
  }

  function downloadBlob(blob: Blob, filename: string) {
    const link = document.createElement("a");
    link.href = URL.createObjectURL(blob); link.download = filename; link.click();
    window.setTimeout(() => URL.revokeObjectURL(link.href), 1000);
  }

  async function exportProject(format: "kml" | "kmz") {
    const kml = kmlDocument();
    if (format === "kml") downloadBlob(new Blob([kml], { type: "application/vnd.google-earth.kml+xml" }), "nexmap-ctos.kml");
    else {
      const zip = new JSZip(); zip.file("doc.kml", kml);
      downloadBlob(await zip.generateAsync({ type: "blob", compression: "DEFLATE" }), "nexmap-ctos.kmz");
    }
    setToast(`Projeto exportado em ${format.toUpperCase()}.`);
  }

  async function toggleTechnicianMode() {
    if (technicianMode) {
      setAuthError(""); setAuthOpen(true);
      return;
    }
    await fetch("/api/management-auth", { method: "DELETE" }).catch(() => {});
    setTechnicianMode(true); setActivePanel(null); setSelected(null);
    const url = new URL(window.location.href);
    url.searchParams.set("modo", "tecnico");
    window.history.replaceState({}, "", url);
    setToast("Modo técnico ativado: somente consulta e navegação.");
  }

  async function unlockManagement(e: FormEvent<HTMLFormElement>) {
    e.preventDefault(); setAuthError("");
    const password = String(new FormData(e.currentTarget).get("password") || "");
    const response = await fetch("/api/management-auth", { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify({ password }) });
    if (!response.ok) return setAuthError("Senha incorreta. Tente novamente.");
    setTechnicianMode(false); setAuthOpen(false); setActivePanel(null); setSelected(null);
    const url = new URL(window.location.href); url.searchParams.delete("modo"); window.history.replaceState({}, "", url);
    setToast("Modo Gestão liberado.");
  }

  async function importProject(e: ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0];
    e.target.value = "";
    if (!file) return;
    try {
      const fileBaseName = file.name.replace(/\.(kml|kmz)$/i, "");
      const destinationFolder = importFolderChoice === "__new__" ? (newImportFolder.trim() || fileBaseName) : importFolderChoice;
      let kml = "";
      if (file.name.toLowerCase().endsWith(".kmz")) {
        const zip = await JSZip.loadAsync(await file.arrayBuffer());
        const entry = Object.values(zip.files).find(item => !item.dir && item.name.toLowerCase().endsWith(".kml"));
        if (!entry) throw new Error("KML não encontrado");
        kml = await entry.async("text");
      } else if (file.name.toLowerCase().endsWith(".kml")) {
        kml = await file.text();
      } else {
        throw new Error("Formato inválido");
      }

      const xml = new DOMParser().parseFromString(kml, "application/xml");
      if (xml.querySelector("parsererror")) throw new Error("Arquivo inválido");
      const directChild = (element: Element, name: string) => Array.from(element.children).find(child => child.localName === name);
      const styleById = new Map<string, Element>();
      Array.from(xml.getElementsByTagNameNS("*", "Style")).forEach(style => {
        const id = style.getAttribute("id");
        if (id) styleById.set(id, style);
      });
      const styleMapById = new Map<string, Element>();
      Array.from(xml.getElementsByTagNameNS("*", "StyleMap")).forEach(styleMap => {
        const id = styleMap.getAttribute("id");
        if (id) styleMapById.set(id, styleMap);
      });
      const resolveStyle = (placemark: Element) => {
        const inlineStyle = directChild(placemark, "Style");
        if (inlineStyle) return inlineStyle;
        const styleId = directChild(placemark, "styleUrl")?.textContent?.trim().replace(/^#/, "");
        if (!styleId) return undefined;
        const sharedStyle = styleById.get(styleId);
        if (sharedStyle) return sharedStyle;
        const styleMap = styleMapById.get(styleId);
        if (!styleMap) return undefined;
        const pairs = Array.from(styleMap.children).filter(child => child.localName === "Pair");
        const pair = pairs.find(item => directChild(item, "key")?.textContent?.trim() === "normal") || pairs[0];
        if (!pair) return undefined;
        const pairInlineStyle = directChild(pair, "Style");
        if (pairInlineStyle) return pairInlineStyle;
        const pairStyleId = directChild(pair, "styleUrl")?.textContent?.trim().replace(/^#/, "");
        return pairStyleId ? styleById.get(pairStyleId) : undefined;
      };
      const kmlColor = (placemark: Element, styleType: "LineStyle" | "IconStyle", fallback: string) => {
        const style = resolveStyle(placemark);
        const raw = style && directChild(directChild(style, styleType) || style, "color")?.textContent?.trim().replace(/^#/, "");
        if (!raw || !/^[0-9a-f]{6,8}$/i.test(raw)) return fallback;
        const color = raw.length === 8 ? raw.slice(2) : raw;
        return `#${color.slice(4, 6)}${color.slice(2, 4)}${color.slice(0, 2)}`.toLowerCase();
      };
      const placemarks = Array.from(xml.querySelectorAll("Placemark"));
      const imported = placemarks.flatMap((placemark, index) => {
        const coordinateText = placemark.querySelector("Point coordinates")?.textContent?.trim();
        if (!coordinateText) return [];
        const [longitude, latitude] = coordinateText.split(",").map(Number);
        if (!Number.isFinite(latitude) || !Number.isFinite(longitude)) return [];
        const name = placemark.querySelector("name")?.textContent?.trim() || `Ponto importado ${index + 1}`;
        const description = placemark.querySelector("description")?.textContent?.replace(/<[^>]*>/g, " ").trim() || "";
        return [{
          id: Date.now() + index,
          name,
          address: description || `Importado do ${importSource}`,
          latitude,
          longitude,
          totalPorts: 8,
          occupiedPorts: 0,
          power: "Não informado",
          status: "Importada",
          color: colorByRouteName(`${name} ${description}`, kmlColor(placemark, "IconStyle", "#0f9f6e")),
          folder: destinationFolder,
          notes: `Origem: ${importSource} • Arquivo: ${file.name}`,
        } satisfies Cto];
      });
      const importedCables = placemarks.flatMap((placemark, index) => {
        const coordinateText = placemark.querySelector("LineString coordinates")?.textContent?.trim();
        if (!coordinateText) return [];
        const points = coordinateText.split(/\s+/).flatMap<[number, number]>(coordinate => {
          const [longitude, latitude] = coordinate.split(",").map(Number);
          return Number.isFinite(latitude) && Number.isFinite(longitude) ? [[latitude, longitude]] : [];
        });
        if (points.length < 2) return [];
        const name = placemark.querySelector("name")?.textContent?.trim() || `Cabo importado ${index + 1}`;
        const description = placemark.querySelector("description")?.textContent?.replace(/<[^>]*>/g, " ").trim() || "";
        const type = description.match(/Tipo:\s*([^\n•]+)/i)?.[1]?.trim() || "Cabo importado";
        const color = colorByRouteName(`${name} ${description}`, kmlColor(placemark, "LineStyle", "#f97316"));
        return [{ id: Date.now() + 10000 + index, name, type, color, points, visible: true, sourceFolder: destinationFolder } satisfies Cable];
      });
      if (!imported.length && !importedCables.length) throw new Error("Nenhum ponto ou cabo encontrado");

      const saved = await Promise.all(imported.map(async point => {
        try {
          const { id: importedId, ...payload } = point;
          void importedId;
          const response = await fetch("/api/ctos", {
            method: "POST",
            headers: { "content-type": "application/json" },
            body: JSON.stringify(payload),
          });
          if (!response.ok) return point;
          return { ...((await response.json()).cto as Cto), folder: point.folder };
        } catch {
          return point;
        }
      }));
      await fetch("/api/folders", { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify({ name: destinationFolder }) });
      setCtos(current => [...current.filter(cto => cto.id > 0), ...saved]);
      setCables(current => [...current, ...importedCables]);
      setActiveFolder(destinationFolder);
      setVisibleFolders(new Set([destinationFolder]));
      setImportOpen(false);
      setNewImportFolder("");
      const importedBounds: [number, number][] = [...saved.map(point => [point.latitude, point.longitude] as [number, number]), ...importedCables.flatMap(cable => cable.points)];
      if (importedBounds.length) mapRef.current?.fitBounds(importedBounds, { padding: [60, 60], maxZoom: 17 });
      setToast(`${saved.length} CTO${saved.length === 1 ? "" : "s"} e ${importedCables.length} cabo${importedCables.length === 1 ? "" : "s"} salvos na pasta “${destinationFolder}”.`);
    } catch {
      setToast("Não foi possível importar. Use um KML ou KMZ com CTOs em pontos e cabos em linhas.");
    }
  }

  function openInChromeForImport() {
    const currentUrl = window.location.href;
    const chromeTarget = currentUrl.replace(/^https?:\/\//, "");
    const fallbackUrl = encodeURIComponent(currentUrl);
    window.location.href = `intent://${chromeTarget}#Intent;scheme=https;package=com.android.chrome;S.browser_fallback_url=${fallbackUrl};end`;
  }

  async function save(e: FormEvent<HTMLFormElement>) {
    e.preventDefault();
    const fd = new FormData(e.currentTarget);
    const payload = {
      name: String(fd.get("name")), address: String(fd.get("address")),
      latitude: Number(fd.get("latitude")), longitude: Number(fd.get("longitude")),
      totalPorts: Number(fd.get("totalPorts")), occupiedPorts: Number(fd.get("occupiedPorts")),
      power: String(fd.get("power")), status: "Ativa", notes: String(fd.get("notes")), color: "#0f9f6e", folder: "CTOs cadastradas",
    };
    try {
      const r = await fetch("/api/ctos", { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify(payload) });
      if (!r.ok) throw new Error();
      const data = await r.json();
      setCtos(v => [...v.filter(c => c.id > 0), data.cto]);
      setSelected(data.cto);
      setToast("CTO cadastrada com sucesso.");
    } catch {
      const local = { ...payload, id: Date.now() };
      setCtos(v => [...v, local]); setSelected(local);
      setToast("CTO adicionada nesta demonstração.");
    }
    setFormOpen(false);
  }

  return (
    <main className="app-shell">
      {splashVisible && (
        <div className="splash-screen" role="status" aria-label="Carregando NEXORA">
          <div className="splash-brand">
            <span className="nexora-mark nexora-mark-large" aria-hidden="true"><b>N</b></span>
            <strong>NEXORA</strong>
            <small>MAPA DE REDE FTTH</small>
            <span className="splash-progress" aria-hidden="true"><i /></span>
          </div>
        </div>
      )}
      <header className="topbar">
        <div className="brand">
          <span className="nexora-mark" aria-hidden="true"><b>N</b></span>
          <div><strong>NEXORA</strong><small>MAPA DE REDE FTTH</small></div>
        </div>
        <button className={`mode-button ${technicianMode ? "technician" : ""}`} onClick={toggleTechnicianMode}>{technicianMode ? "Modo Técnico" : "Modo Gestão"}</button>
        {!installed && (
          <button className="install-app-button" onClick={installApp} aria-label="Instalar NEX'MAP no dispositivo">
            <span aria-hidden="true">⇩</span>
            <b>Instalar app</b>
          </button>
        )}
        {!isOnline && <span className="offline-badge" title="Usando os dados salvos no aparelho">Offline</span>}
        <div className="map-heading"><strong>Mapa operacional</strong><small>CTOs e referências da rede</small></div>
      </header>

      <section className="workspace">
        <div className="map-wrap">
          <div ref={mapEl} className="map" />
          <button
            className={`map-style-card ${mapStyle === "satellite" ? "show-map" : "show-satellite"}`}
            onClick={() => setMapStyle(current => current === "map" ? "satellite" : "map")}
            aria-label={`Mudar para visualização ${mapStyle === "map" ? "por satélite" : "de mapa"}`}
          >
            <span className="map-style-preview" aria-hidden="true"><i /></span>
            <span className="map-style-copy"><small>VISUALIZAÇÃO</small><strong>{mapStyle === "map" ? "Satélite" : "Mapa"}</strong></span>
            <span className="map-style-arrow" aria-hidden="true">↗</span>
          </button>
          <nav className="side-tabs" aria-label="Opções do mapa">
            <button className={activePanel === "list" ? "active" : ""} onClick={() => togglePanel("list")} aria-label="Árvore de elementos"><span>▦</span><small>Elementos</small></button>
            <button className={activePanel === "search" ? "active" : ""} onClick={() => togglePanel("search")} aria-label="Buscar CTO"><span>⌕</span><small>Buscar</small></button>
            {!technicianMode && <button className={activePanel === "add" ? "active" : ""} onClick={() => togglePanel("add")} aria-label="Abrir aba para adicionar CTO"><span>＋</span><small>CTO</small></button>}
            {!technicianMode && <button className={activePanel === "cables" ? "active" : ""} onClick={() => togglePanel("cables")} aria-label="Cabos e ramais"><span>〰</span><small>Cabos</small></button>}
            {!technicianMode && <button onClick={() => setImportOpen(true)} aria-label="Importar do Google Earth ou GeoGrid"><span>⇩</span><small>Importar</small></button>}
            {!technicianMode && <button onClick={() => exportProject("kmz")} aria-label="Exportar projeto KMZ"><span>⇧</span><small>Exportar</small></button>}
            {!technicianMode && <button onClick={() => exportProject("kml")} aria-label="Exportar projeto KML"><span>↗</span><small>KML</small></button>}
            <button onClick={locateMe} aria-label="Minha localização"><span>⌖</span><small>Localizar</small></button>
          </nav>

          {activePanel && <aside className="sidebar open">
            <button className="drawer-close" onClick={() => setActivePanel(null)} aria-label="Fechar painel">×</button>
            <div className="side-title"><div><small>NEXORA • REDE FTTH</small><h1>{activePanel === "search" ? "Buscar CTO" : activePanel === "add" ? "Adicionar CTO" : activePanel === "cables" ? "Cabos e ramais" : "Árvore de CTOs"}</h1></div><b>{activePanel === "cables" ? cables.length : ctos.length}</b></div>
            {activePanel === "search" && <div className="drawer-search"><span>⌕</span><input autoFocus value={query} onChange={e => setQuery(e.target.value)} placeholder="Nome, rua ou região..." /></div>}
            {activePanel === "add" && <div className="tool-panel">
              <div className="tool-card"><span>＋</span><div><strong>Nova caixa CTO</strong><small>Cadastre a caixa e escolha sua posição no mapa.</small></div></div>
              <p>Toque no botão abaixo e confirme nome, portas, potência e referência. Você também pode tocar diretamente no mapa para usar aquela posição.</p>
              <button className="tool-primary" onClick={() => setFormOpen(true)}>Adicionar nova CTO</button>
            </div>}
            {activePanel === "cables" && <div className="cable-panel">
              <div className="tool-card cable"><span>〰</span><div><strong>Ligação óptica</strong><small>Desenhe cabos entre CTOs, postes e ramais.</small></div></div>
              <button className="tool-primary cable-action" onClick={beginCable}>＋ Adicionar cabo</button>
              <section className="cable-section">
                <button className="cable-section-head" onClick={() => setCablesExpanded(current => !current)}><span>Cabos cadastrados</span><b>{cablesExpanded ? "⌃" : "⌄"}</b></button>
                {cablesExpanded && <div className="cable-list">{cables.map(cable => <article className={`cable-row ${cable.visible ? "visible" : ""}`} key={cable.id}>
                  <button className="cable-toggle" onClick={() => toggleCable(cable.id)}><i style={{ background: colorByRouteName(cable.name, cable.color) }} /><span><strong>{cable.name}</strong><small>{cable.type} • {cable.points.length} pontos</small></span><b>{cable.visible ? "●" : "○"}</b></button>
                  <button className="cable-delete" onClick={() => deleteCable(cable.id)}>Excluir</button>
                </article>)}{!cables.length && <p className="empty-state">Nenhum cabo adicionado.</p>}</div>}
              </section>
            </div>}
            {activePanel === "list" && <div className="element-tree">
              <div className="tree-search">
                <label htmlFor="tree-search">Buscar elementos</label>
                <div><span>⌕</span><input id="tree-search" value={query} onChange={e => setQuery(e.target.value)} placeholder="Nome, rota, rua ou região..." /></div>
              </div>
              <div className="tree-project">
                <span className="tree-project-icon">N</span>
                <div><small>PROJETO ATIVO</small><strong>Rede Nexora FTTH</strong></div>
                <button aria-label="Mais opções do projeto">•••</button>
              </div>
              {!technicianMode && <button className="create-folder-button" onClick={() => setFolderOpen(true)}>
                <span aria-hidden="true">＋</span><div><strong>Criar nova pasta</strong><small>Organize CTOs, cabos e importações</small></div><b>›</b>
              </button>}
              <button className={`tree-all ${allFoldersVisible ? "checked" : ""}`} onClick={toggleAllElements} role="checkbox" aria-checked={allFoldersVisible}>
                <span>{allFoldersVisible ? "✓" : visibleFolders.size ? "−" : ""}</span>
                <strong>Exibir tudo</strong>
                <small>{ctos.length} elementos</small>
              </button>
              <div className="tree-divider" />
              <section className="tree-section">
                <button className="tree-section-head" onClick={() => setCtosExpanded(current => !current)} aria-expanded={ctosExpanded}>
                  <span className={`tree-check ${visibleFolders.size ? "checked" : ""}`}>{allFoldersVisible ? "✓" : visibleFolders.size ? "−" : ""}</span>
                  <span className="tree-type-icon">CTO</span>
                  <div><strong>Caixas CTO</strong><small>{visibleFolders.size} de {folders.length} pastas visíveis</small></div>
                  <b>{ctosExpanded ? "⌃" : "⌄"}</b>
                </button>
                {ctosExpanded && <div className="tree-children">
                  {folders.map(folder => {
                    const visible = visibleFolders.has(folder.name);
                    const folderCtos = ctos.filter(cto => folderOf(cto) === folder.name && `${cto.name} ${cto.address}`.toLowerCase().includes(query.toLowerCase()));
                    const folderCables = cables.filter(cable => (cable.sourceFolder || "CTOs cadastradas") === folder.name && `${cable.name} ${cable.type}`.toLowerCase().includes(query.toLowerCase()));
                    return <div className="tree-folder" key={folder.name}>
                      <div className={`tree-child ${visible ? "visible" : ""}`}>
                        <button className="child-toggle" onClick={() => toggleFolderVisibility(folder.name)} role="checkbox" aria-checked={visible}>
                          <span>{visible ? "✓" : ""}</span><div><strong>{folder.name}</strong><small>{folder.ctos} CTOs{folder.cables ? ` • ${folder.cables} cabos` : ""}</small></div>
                        </button>
                        <button className="child-open" onClick={() => setActiveFolder(current => current === folder.name ? null : folder.name)} aria-label={`Abrir pasta ${folder.name}`}>{activeFolder === folder.name ? "⌃" : "⌄"}</button>
                        {!technicianMode && folders.length > 1 && <button className="child-move" onClick={() => openMoveFolder(folder.name)} aria-label={`Mover elementos de ${folder.name} para outra pasta`} title="Mover para outra pasta">⇄</button>}
                        {!technicianMode && <button type="button" className="child-delete" onClick={() => setDeleteFolderName(folder.name)} aria-label={`Excluir pasta ${folder.name}`} title="Excluir pasta completa">⌫</button>}
                      </div>
                      {activeFolder === folder.name && <div className="tree-leaves">
                        {!technicianMode && <div className="folder-open-actions">
                          <button type="button" className="folder-edit-action" onClick={() => openEditFolder(folder.name)}>✎ Editar nome</button>
                          <button type="button" className="folder-delete-action" onClick={() => setDeleteFolderName(folder.name)}>⌫ Excluir pasta</button>
                        </div>}
                        {folderCtos.map(cto => <div className="tree-leaf-row" key={`cto-${cto.id}`}>
                          <button className="tree-leaf-open" onClick={() => focus(cto)}>
                            <span className={`leaf-dot ${cto.occupiedPorts >= cto.totalPorts ? "full" : ""}`} />
                            <div><strong>{cto.name}</strong><small>CTO • {cto.address}</small></div><b>›</b>
                          </button>
                          {!technicianMode && <button className="leaf-delete" onClick={() => deleteCto(cto)} aria-label={`Excluir ${cto.name}`} title="Excluir elemento">⌫</button>}
                        </div>)}
                        {folderCables.map(cable => <div className="tree-leaf-row cable-leaf" key={`cable-${cable.id}`}>
                          <button className="tree-leaf-open" onClick={() => toggleCable(cable.id)}>
                            <span className="leaf-cable-line" style={{ background: colorByRouteName(cable.name, cable.color) }} />
                            <div><strong>{cable.name}</strong><small>Cabo • {cable.type}</small></div><b>{cable.visible ? "●" : "○"}</b>
                          </button>
                          {!technicianMode && <button className="leaf-delete" onClick={() => deleteCable(cable.id)} aria-label={`Excluir ${cable.name}`} title="Excluir elemento">⌫</button>}
                        </div>)}
                        {!folderCtos.length && !folderCables.length && <small className="tree-no-results">Nenhum elemento encontrado.</small>}
                      </div>}
                    </div>;
                  })}
                </div>}
              </section>
            </div>}
            {activePanel === "search" && <div className="cto-list">
              {filtered.map(cto => <button key={cto.id} className={`cto-card ${selected?.id === cto.id ? "selected" : ""}`} onClick={() => focus(cto)}>
                <span className={`status-dot ${cto.occupiedPorts >= cto.totalPorts ? "full" : ""}`} />
                <div><strong>{cto.name}</strong><small>{cto.address}</small><div className="port-line"><span>{cto.totalPorts - cto.occupiedPorts} portas livres</span><span>{cto.power}</span></div></div>
                <span className="chevron">›</span>
              </button>)}
              {!filtered.length && <p className="empty-state">{activePanel === "list" && !activeFolder ? "Abra uma pasta para carregar seus elementos no mapa." : "Nenhuma CTO encontrada."}</p>}
            </div>}
            <div className="legend"><span><i className="green" /> Com portas</span><span><i className="orange" /> Lotada</span></div>
          </aside>}

          <button className="location-button" onClick={locateMe} aria-label="Minha localização">⌖</button>
          <div className="map-tip"><span>Toque em uma CTO para abrir as referências</span></div>
          {selected && <article className="detail-card">
            <button className="close-detail" onClick={() => setSelected(null)}>×</button>
            <div className="detail-head"><span className="detail-icon"><img src="/cto-marker.jpg" alt="" /></span><div><small>CAIXA DE TERMINAÇÃO ÓPTICA</small><h2>{selected.name}</h2><p>● {selected.status}</p></div></div>
            <p className="address">⌖ {selected.address}</p>
            <div className="metrics"><div><small>PORTAS</small><b>{selected.occupiedPorts}/{selected.totalPorts}</b><span>ocupadas</span></div><div><small>POTÊNCIA</small><b>{selected.power}</b><span>última medição</span></div></div>
            <p className="notes">{selected.notes || "Sem observações cadastradas."}</p>
            {nearestId === selected.id && <p className="nearest-badge">✓ CTO mais próxima da sua localização</p>}
            <div className="detail-actions">{!technicianMode && <button className="primary-action" onClick={() => setEditOpen(true)}>Editar CTO</button>}{!technicianMode && <button onClick={startRelocating}>Reposicionar</button>}<a target="_blank" rel="noreferrer" href={`https://www.google.com/maps/dir/?api=1&destination=${selected.latitude},${selected.longitude}`}>Traçar rota</a><button onClick={() => { navigator.clipboard?.writeText(`${selected.latitude}, ${selected.longitude}`); setToast("Localização copiada."); }}>Copiar localização</button></div>
          </article>}
          {relocatingId && <div className="relocation-tip"><b>Reposicionando CTO</b><span>Arraste a caixa e solte no ponto correto.</span><button onClick={() => setRelocatingId(null)}>Cancelar</button></div>}
          {drawingCable && <div className="cable-drawing-tip"><div><b>Desenhando cabo</b><span>{cablePoints.length} ponto{cablePoints.length === 1 ? "" : "s"} marcado{cablePoints.length === 1 ? "" : "s"}. Toque no mapa ou em uma CTO.</span></div><button className="undo-point" disabled={!cablePoints.length} onClick={() => setCablePoints(current => current.slice(0, -1))}>↶ Último ponto</button><button onClick={() => { setDrawingCable(false); setCablePoints([]); }}>Cancelar</button><button className="finish" onClick={finishCable}>Concluir cabo</button></div>}
        </div>
      </section>

      {!drawingCable && cablePoints.length >= 2 && <div className="modal-backdrop">
        <form className="modal" onSubmit={saveCable}>
          <button type="button" className="modal-close" onClick={() => setCablePoints([])}>×</button>
          <small>NOVA LIGAÇÃO ÓPTICA</small><h2>Identificar cabo</h2><p>Salve o trecho que liga as CTOs aos ramais.</p>
          <label>Identificação do cabo<input name="name" required placeholder="Ex.: Cabo ASU 12FO • Ramal Fazenda União" /></label>
          <label>Tipo ou capacidade<select name="type" defaultValue="ASU 12FO"><option>ASU 6FO</option><option>ASU 12FO</option><option>ASU 24FO</option><option>ASU 36FO</option><option>ASU 48FO</option><option>ASU 72FO</option><option>ASU 120FO</option><option>Drop</option></select></label>
          <label>Cor no mapa<div className="color-field"><input name="color" type="color" defaultValue="#f97316" /><span>Use cores diferentes para identificar os ramais</span></div></label>
          <button className="save-button">Salvar cabo no mapa</button>
        </form>
      </div>}

      {authOpen && <div className="modal-backdrop" onMouseDown={e => e.target === e.currentTarget && setAuthOpen(false)}>
        <form className="modal management-login" onSubmit={unlockManagement}>
          <button type="button" className="modal-close" onClick={() => setAuthOpen(false)}>×</button>
          <span className="management-lock" aria-hidden="true">▣</span>
          <small>ÁREA RESTRITA</small><h2>Acessar Modo Gestão</h2><p>Digite a senha administrativa para cadastrar, editar ou excluir elementos da rede.</p>
          <label>Senha de acesso<input name="password" type="password" inputMode="text" autoFocus required autoComplete="current-password" placeholder="Digite sua senha" /></label>
          {authError && <p className="auth-error" role="alert">{authError}</p>}
          <button className="save-button">Entrar no Modo Gestão</button>
        </form>
      </div>}

      {folderOpen && !technicianMode && <div className="modal-backdrop" onMouseDown={e => e.target === e.currentTarget && setFolderOpen(false)}>
        <form className="modal create-folder-modal" onSubmit={createFolder}>
          <button type="button" className="modal-close" onClick={() => setFolderOpen(false)}>×</button>
          <span className="folder-modal-icon" aria-hidden="true">▰</span>
          <small>ORGANIZAÇÃO DO PROJETO</small><h2>Criar nova pasta</h2><p>Crie uma pasta para separar as CTOs, cabos e próximas importações por região ou ramal.</p>
          <label>Nome da pasta<input name="folderName" autoFocus required maxLength={60} placeholder="Ex.: Ramal Dona América" /></label>
          <button className="save-button">Criar pasta</button>
        </form>
      </div>}

      {formOpen && <div className="modal-backdrop" onMouseDown={e => e.target === e.currentTarget && setFormOpen(false)}>
        <form className="modal" onSubmit={save}>
          <button type="button" className="modal-close" onClick={() => setFormOpen(false)}>×</button>
          <small>NOVO PONTO DE REDE</small><h2>Adicionar caixa CTO</h2><p>Confirme a posição e informe os dados da caixa.</p>
          <label>Identificação da CTO<input name="name" required placeholder="Ex.: CTO MC-032" /></label>
          <label>Endereço ou referência<input name="address" required placeholder="Rua, número ou ponto de referência" /></label>
          <div className="form-grid"><label>Latitude<input name="latitude" type="number" step="any" required value={picked.lat} onChange={e => setPicked(v => ({...v, lat: Number(e.target.value)}))} /></label><label>Longitude<input name="longitude" type="number" step="any" required value={picked.lng} onChange={e => setPicked(v => ({...v, lng: Number(e.target.value)}))} /></label></div>
          <div className="form-grid"><label>Total de portas<input name="totalPorts" type="number" min="1" defaultValue="8" required /></label><label>Portas ocupadas<input name="occupiedPorts" type="number" min="0" defaultValue="0" required /></label></div>
          <label>Potência medida<input name="power" placeholder="Ex.: -18,5 dBm" /></label>
          <label>Observações<textarea name="notes" placeholder="Poste, referência, splitter, acesso..." /></label>
          <button className="save-button">Salvar CTO no mapa</button>
        </form>
      </div>}
      {importOpen && <div className="modal-backdrop" onMouseDown={e => e.target === e.currentTarget && setImportOpen(false)}>
        <section className="modal import-modal" aria-modal="true" role="dialog" aria-labelledby="import-title">
          <button type="button" className="modal-close" onClick={() => setImportOpen(false)}>×</button>
          <small>IMPORTAÇÃO DE PROJETO</small><h2 id="import-title">Importar CTOs e cabos</h2>
          <p>O mesmo arquivo KML ou KMZ pode trazer as caixas CTO como pontos e os cabos ou ramais como linhas.</p>
          <div className="import-sources">
            <button className={importSource === "Google Earth" ? "selected" : ""} onClick={() => setImportSource("Google Earth")}><span>◉</span><strong>Google Earth</strong><small>Arquivos KML ou KMZ</small></button>
            <button className={importSource === "GeoGrid" ? "selected" : ""} onClick={() => setImportSource("GeoGrid")}><span>▦</span><strong>GeoGrid</strong><small>Arquivos KML ou KMZ</small></button>
          </div>
          <div className="import-folder-box">
            <span className="folder-box-icon" aria-hidden="true">▰</span>
            <div><strong>Salvar importação em</strong><small>Crie uma pasta separada ou junte a uma pasta existente.</small></div>
          </div>
          <label>Pasta de destino
            <select value={importFolderChoice} onChange={e => setImportFolderChoice(e.target.value)}>
              <option value="__new__">＋ Criar nova pasta</option>
              {folders.map(folder => <option key={folder.name} value={folder.name}>{folder.name}</option>)}
            </select>
          </label>
          <div className="single-folder-notice"><span aria-hidden="true">✓</span><div><strong>Seleção individual</strong><small>Somente {importFolderChoice === "__new__" ? "a nova pasta" : `a pasta “${importFolderChoice}”`} receberá este arquivo.</small></div></div>
          {importFolderChoice === "__new__" && <label>Nome da nova pasta<input value={newImportFolder} onChange={e => setNewImportFolder(e.target.value)} placeholder="Ex.: Ramal Dona América" /><small className="field-help">Se deixar vazio, será usado o nome do arquivo.</small></label>}
          <div className="import-help"><b>Análise automática antes de importar</b><span>O NEX’MAP lê os nomes antes de salvar. Identificações como R6 são agrupadas; no padrão CTO-03.20, CT8.20 ou CTO-01.20_splitter, o número final “20” identifica o ramal. Splitters e elementos com a mesma identificação recebem a mesma cor.</span></div>
          <div className="device-file-help"><span aria-hidden="true">▤</span><div><strong>Arquivo salvo no celular</strong><small>Abra Downloads, Recentes ou outra pasta do aparelho.</small></div></div>
          {isAndroid && <div className="external-browser-help">
            <strong>Está vendo somente câmera e fotos?</strong>
            <small>Este navegador interno limita a seleção. Abra o app no Chrome e importe pela pasta Downloads.</small>
            <button type="button" className="chrome-import-button" onClick={openInChromeForImport}>Abrir no Chrome para importar</button>
          </div>}
          <input ref={importFileRef} className="file-input" type="file" accept=".kml,.kmz,application/vnd.google-earth.kml+xml,application/vnd.google-earth.kmz,application/zip,application/octet-stream,application/xml" onChange={importProject} />
          <button className="save-button" onClick={() => importFileRef.current?.click()}>Abrir Downloads / Arquivos</button>
          <small className="supported-files">Formatos aceitos: KML e KMZ do {importSource}</small>
        </section>
      </div>}
      {moveFolderName && <div className="modal-backdrop" onMouseDown={e => e.target === e.currentTarget && setMoveFolderName(null)}>
        <form className="modal move-folder-modal" onSubmit={moveFolderContents}>
          <button type="button" className="modal-close" onClick={() => setMoveFolderName(null)}>×</button>
          <span className="move-folder-icon" aria-hidden="true">⇄</span>
          <small>ORGANIZAR ELEMENTOS</small><h2>Mover para outra pasta</h2>
          <p>Todos os cabos e CTOs de <strong>{moveFolderName}</strong> serão transferidos sem precisar importar novamente.</p>
          <label>Pasta de destino
            <select required value={moveDestination} onChange={e => setMoveDestination(e.target.value)}>
              {folders.filter(folder => folder.name !== moveFolderName).map(folder => <option key={folder.name} value={folder.name}>{folder.name}</option>)}
            </select>
          </label>
          <button className="save-button" disabled={!moveDestination}>Mover elementos</button>
          <button type="button" className="move-cancel-button" onClick={() => setMoveFolderName(null)}>Cancelar</button>
        </form>
      </div>}
      {deleteFolderName && <div className="modal-backdrop" onMouseDown={e => e.target === e.currentTarget && setDeleteFolderName(null)}>
        <section className="modal delete-folder-modal" role="dialog" aria-modal="true" aria-labelledby="delete-folder-title">
          <button type="button" className="modal-close" onClick={() => setDeleteFolderName(null)}>×</button>
          <span className="delete-folder-icon" aria-hidden="true">⌫</span>
          <small>EXCLUSÃO DE PASTA</small><h2 id="delete-folder-title">Excluir pasta completa?</h2>
          <p>A pasta <strong>{deleteFolderName}</strong> e todas as CTOs e cabos guardados nela serão apagados. Esta ação não poderá ser desfeita.</p>
          <button type="button" className="confirm-folder-delete" disabled={deletingFolder} onClick={() => void deleteFolder(deleteFolderName)}>{deletingFolder ? "Excluindo pasta..." : "Sim, excluir pasta completa"}</button>
          <button type="button" className="move-cancel-button" onClick={() => setDeleteFolderName(null)}>Cancelar</button>
        </section>
      </div>}
      {editFolderName && <div className="modal-backdrop" onMouseDown={e => e.target === e.currentTarget && setEditFolderName(null)}>
        <form className="modal edit-folder-modal" onSubmit={renameFolder}>
          <button type="button" className="modal-close" onClick={() => setEditFolderName(null)}>×</button>
          <span className="edit-folder-icon" aria-hidden="true">✎</span>
          <small>ORGANIZAR PASTA</small><h2>Editar nome da pasta</h2>
          <p>As CTOs e os cabos continuarão dentro desta pasta.</p>
          <label>Novo nome<input autoFocus required value={editFolderValue} onChange={e => setEditFolderValue(e.target.value)} /></label>
          <button className="save-button">Salvar novo nome</button>
          <button type="button" className="move-cancel-button" onClick={() => setEditFolderName(null)}>Cancelar</button>
        </form>
      </div>}
      {editOpen && selected && <div className="modal-backdrop" onMouseDown={e => e.target === e.currentTarget && setEditOpen(false)}>
        <form className="modal edit-cto-modal" onSubmit={editCto}>
          <button type="button" className="modal-close" onClick={() => setEditOpen(false)}>×</button>
          <small>PERSONALIZAR CAIXA</small><h2>Editar CTO</h2><p>Altere a identificação, a cor e a posição exata no mapa.</p>
          <label>Nome da CTO<input name="name" required defaultValue={selected.name} /></label>
          <label>Endereço ou referência<input name="address" required defaultValue={selected.address} /></label>
          <label>Pasta ou região<input name="folder" defaultValue={folderOf(selected)} /></label>
          <label>Cor da caixa<div className="color-field"><input name="color" type="color" defaultValue={selected.color || "#0f9f6e"} /><span>Escolha uma cor para identificar esta CTO</span></div></label>
          <div className="form-grid"><label>Latitude<input name="latitude" type="number" step="any" required defaultValue={selected.latitude} /></label><label>Longitude<input name="longitude" type="number" step="any" required defaultValue={selected.longitude} /></label></div>
          <div className="form-grid"><label>Total de portas<input name="totalPorts" type="number" min="1" required defaultValue={selected.totalPorts} /></label><label>Portas ocupadas<input name="occupiedPorts" type="number" min="0" required defaultValue={selected.occupiedPorts} /></label></div>
          <div className="form-grid"><label>Potência<input name="power" defaultValue={selected.power} /></label><label>Status<input name="status" defaultValue={selected.status} /></label></div>
          <label>Observações<textarea name="notes" defaultValue={selected.notes} /></label>
          <button className="save-button">Salvar alterações</button>
          <button type="button" className="delete-button" onClick={() => deleteCto()}>Excluir esta CTO</button>
        </form>
      </div>}
      {toast && <button className="toast" onClick={() => setToast("")}>{toast} ×</button>}
    </main>
  );
}
