import type { Metadata } from "next";
import { Geist, Geist_Mono } from "next/font/google";
import "./globals.css";

const geistSans = Geist({
  variable: "--font-geist-sans",
  subsets: ["latin"],
});

const geistMono = Geist_Mono({
  variable: "--font-geist-mono",
  subsets: ["latin"],
});

export const metadata: Metadata = {
  title: "Nexora | Mapa de CTOs",
  description: "Localização e gestão das caixas CTO da rede FTTH.",
  manifest: "/manifest.webmanifest",
  applicationName: "NEX'MAP",
  appleWebApp: {
    capable: true,
    statusBarStyle: "black-translucent",
    title: "NEX'MAP",
  },
  themeColor: "#0c251d",
  other: {
    "codex-preview": "development",
  },
  icons: {
    icon: [
      { url: "/icons/nexora-192.png", sizes: "192x192", type: "image/png" },
      { url: "/favicon.svg", type: "image/svg+xml" },
    ],
    shortcut: "/icons/nexora-192.png",
    apple: "/icons/nexora-192.png",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="pt-BR">
      <body
        className={`${geistSans.variable} ${geistMono.variable} antialiased`}
      >
        {children}
      </body>
    </html>
  );
}
