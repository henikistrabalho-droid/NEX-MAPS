const CACHE_NAME = "nexmap-v2";
const MAP_CACHE = "nexmap-map-tiles-v1";
const APP_SHELL = [
  "/",
  "/?modo=tecnico",
  "/manifest.webmanifest",
  "/favicon.svg",
  "/cto-marker.jpg",
  "/icons/nexora-192.png",
  "/icons/nexora-512.png"
];

self.addEventListener("install", event => {
  event.waitUntil(caches.open(CACHE_NAME).then(cache => cache.addAll(APP_SHELL)));
  self.skipWaiting();
});

self.addEventListener("activate", event => {
  event.waitUntil(
    caches.keys().then(keys => Promise.all(keys.filter(key => ![CACHE_NAME, MAP_CACHE].includes(key)).map(key => caches.delete(key))))
  );
  self.clients.claim();
});

self.addEventListener("fetch", event => {
  if (event.request.method !== "GET") return;
  const url = new URL(event.request.url);
  const isMapTile = ["tile.openstreetmap.org", "server.arcgisonline.com"].some(host => url.hostname.endsWith(host));

  if (isMapTile) {
    event.respondWith(caches.open(MAP_CACHE).then(async cache => {
      const cached = await cache.match(event.request);
      if (cached) return cached;
      const response = await fetch(event.request);
      if (response.ok || response.type === "opaque") cache.put(event.request, response.clone());
      return response;
    }));
    return;
  }

  if (url.origin !== self.location.origin) return;
  event.respondWith(fetch(event.request).then(response => {
    if (response.ok) caches.open(CACHE_NAME).then(cache => cache.put(event.request, response.clone()));
    return response;
  }).catch(async () => {
    const cached = await caches.match(event.request);
    if (cached) return cached;
    if (event.request.mode === "navigate") {
      const technicianHome = await caches.match("/?modo=tecnico");
      return technicianHome || await caches.match("/");
    }
    return new Response(JSON.stringify({ offline: true }), { status: 503, headers: { "content-type": "application/json" } });
  }));
});
