import { integer, real, sqliteTable, text } from "drizzle-orm/sqlite-core";

export const ctos = sqliteTable("ctos", {
  id: integer("id").primaryKey({ autoIncrement: true }),
  name: text("name").notNull(),
  address: text("address").notNull().default(""),
  latitude: real("latitude").notNull(),
  longitude: real("longitude").notNull(),
  totalPorts: integer("total_ports").notNull().default(8),
  occupiedPorts: integer("occupied_ports").notNull().default(0),
  power: text("power").notNull().default(""),
  status: text("status").notNull().default("Ativa"),
  notes: text("notes").notNull().default(""),
  color: text("color").notNull().default("#0f9f6e"),
  folder: text("folder").notNull().default("CTOs cadastradas"),
});

export const projectFolders = sqliteTable("project_folders", {
  id: integer("id").primaryKey({ autoIncrement: true }),
  name: text("name").notNull().unique(),
  createdAt: integer("created_at", { mode: "timestamp" }).notNull().$defaultFn(() => new Date()),
});
