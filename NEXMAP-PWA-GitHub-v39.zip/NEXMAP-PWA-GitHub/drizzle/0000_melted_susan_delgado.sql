CREATE TABLE `ctos` (
	`id` integer PRIMARY KEY AUTOINCREMENT NOT NULL,
	`name` text NOT NULL,
	`address` text DEFAULT '' NOT NULL,
	`latitude` real NOT NULL,
	`longitude` real NOT NULL,
	`total_ports` integer DEFAULT 8 NOT NULL,
	`occupied_ports` integer DEFAULT 0 NOT NULL,
	`power` text DEFAULT '' NOT NULL,
	`status` text DEFAULT 'Ativa' NOT NULL,
	`notes` text DEFAULT '' NOT NULL
);
